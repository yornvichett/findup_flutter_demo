import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/constants/text_helper.dart';
import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:findup_mvvm/Core/utils/cache_profile_image.dart';
import 'package:findup_mvvm/Data/models/chat_model.dart';
import 'package:findup_mvvm/Data/models/user_model.dart';
import 'package:findup_mvvm/Data/view_models/chat_view_model.dart';
import 'package:findup_mvvm/Data/view_models/notification_view_model.dart';
import 'package:findup_mvvm/Pages/_Chat/Admin/admin_list_chat_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AdminChatPage extends StatefulWidget {
  final UserModel clientUser;
  final UserModel userAdmin;
  const AdminChatPage({
    super.key,
    required this.clientUser,
    required this.userAdmin,
  });

  @override
  State<AdminChatPage> createState() => _AdminChatPageState();
}

class _AdminChatPageState extends State<AdminChatPage>
    with WidgetsBindingObserver {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  ValueNotifier<List<ChatModel>> tempChatModel = ValueNotifier([]);
  TextHelper textHelper = TextHelper();

  void scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      scrollToBottom();
      tempChatModel.value.clear();
      context.read<ChatViewModel>().userListMessage(
        body: {'user_id': widget.clientUser.id},
      );
    });
  }

  @override
  void didChangeMetrics() {
    final bottomInset = WidgetsBinding.instance.window.viewInsets.bottom;
    if (bottomInset > 0) {
      scrollToBottom(); // keyboard open
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void sendMessage({
    required ChatViewModel chatViewModel,
    required NotificationViewModel notificationViewModel,
  }) async {
    if (_messageController.text.trim().isEmpty) return;

    String text = _messageController.text.trim();
    Map<String, dynamic> body = {
      'admin_id': 2,
      'user_id': widget.clientUser.id,
      'message': text,
      'sender_role': 'admin',
      'image_url': 'default.jpg',
    };

    bool success = await chatViewModel.adminSentMessage(body: body);
    if (success) {
      Map<String, dynamic> jsonBody = {
        'token': widget.clientUser.fcmToken,
        'title': widget.userAdmin.name,
        'body': text,
      };

      await notificationViewModel.pushChatNotification(jsonBody: jsonBody);
      ChatModel chatModel = ChatModel.fromJson(jsonResponse: body);
      tempChatModel.value.add(chatModel);
      scrollToBottom();
    }

    _messageController.clear();
  }

  @override
  Widget build(BuildContext context) {
    ChatViewModel chatViewModel = context.watch<ChatViewModel>();
    NotificationViewModel notificationViewModel = context
        .watch<NotificationViewModel>();
    tempChatModel.value = chatViewModel.listUserMessage;

    return Scaffold(
      resizeToAvoidBottomInset: true, // ✅ allows UI to move with keyboard
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: AppColor.appBarColor,
        leading: GestureDetector(
          onTap: () {
            Navigation.goReplacePage(
              context: context,
              page: AdminListChatPage(userAdmin: widget.userAdmin),
            );
          },
          child: const Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(Icons.arrow_back_ios_new, color: Colors.white),
          ),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        elevation: 1,
        title: Row(
          children: [
            CacheProfileImage(userProfileImage: widget.clientUser.userProfile),
            const SizedBox(width: 10),
            Text(
              widget.clientUser.name,
              style: textHelper.textAppBarStyle(fontSize: 20),
            ),
          ],
        ),
      ),

      body: chatViewModel.isLoading && tempChatModel.value.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(12),
                      itemCount: tempChatModel.value.length,
                      itemBuilder: (context, index) {
                        ChatModel chatModel = tempChatModel.value[index];
                        bool isAdmin = chatModel.senderRolw == "admin";

                        return Container(
                          margin: const EdgeInsets.symmetric(vertical: 3),
                          child: Align(
                            alignment: isAdmin
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              constraints: const BoxConstraints(maxWidth: 280),
                              decoration: BoxDecoration(
                                color: !isAdmin
                                    ? Colors.grey.shade300
                                    : Colors.blue.shade600,
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(16),
                                  topRight: const Radius.circular(16),
                                  bottomLeft: Radius.circular(
                                    !isAdmin ? 0 : 16,
                                  ),
                                  bottomRight: Radius.circular(
                                    !isAdmin ? 16 : 0,
                                  ),
                                ),
                              ),
                              child: Text(
                                chatModel.message,
                                style: TextStyle(
                                  color: !isAdmin
                                      ? Colors.black87
                                      : Colors.white,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  // ✅ Chat Input
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.05),
                          blurRadius: 5,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _messageController,
                            onTap:
                                scrollToBottom, // ✅ Scroll when typing starts
                            decoration: InputDecoration(
                              hintText: "Type a message...",
                              fillColor: Colors.grey.shade100,
                              filled: true,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 10,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        CircleAvatar(
                          backgroundColor: Colors.blue.shade600,
                          child: IconButton(
                            icon: const Icon(Icons.send, color: Colors.white),
                            onPressed: () => sendMessage(
                              chatViewModel: chatViewModel,
                              notificationViewModel: notificationViewModel,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
