import 'dart:ui';

import 'package:findup_mvvm/Core/Storage/show_mode_storage.dart';
import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/constants/text_helper.dart';
import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:findup_mvvm/Core/services/check_screen.dart';
import 'package:findup_mvvm/Core/services/helper.dart';
import 'package:findup_mvvm/Core/services/local_storage.dart';
import 'package:findup_mvvm/Core/services/translate.dart';
import 'package:findup_mvvm/Core/utils/Loading/simmer_show_product_filter_element.dart';
import 'package:findup_mvvm/Core/utils/bottom_slide_element.dart';
import 'package:findup_mvvm/Core/utils/build_list_horizontal_element.dart';
import 'package:findup_mvvm/Core/utils/large_card_item_element.dart';
import 'package:findup_mvvm/Core/utils/list_card_item.dart';
import 'package:findup_mvvm/Core/utils/no_item_text_widget.dart';
import 'package:findup_mvvm/Core/utils/Loading/simmer_loader_element.dart';
import 'package:findup_mvvm/Core/utils/slide_auto_scroll_element.dart';
import 'package:findup_mvvm/Core/utils/small_card_item_element.dart';
import 'package:findup_mvvm/Data/models/group_category_model.dart';
import 'package:findup_mvvm/Data/models/group_place_model.dart';
import 'package:findup_mvvm/Data/models/product_model.dart';
import 'package:findup_mvvm/Data/models/sub_category_model.dart';
import 'package:findup_mvvm/Data/models/sub_place_model.dart';
import 'package:findup_mvvm/Data/view_models/group_place_view_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:findup_mvvm/Data/view_models/slide_view_model.dart';
import 'package:findup_mvvm/Data/view_models/sub_category_view_modle.dart';
import 'package:findup_mvvm/Data/view_models/sub_place_view_model.dart';
import 'package:findup_mvvm/Pages/_Map/map_show_screen.dart';
import 'package:findup_mvvm/Pages/_Search/dialog_search_all.dart';
import 'package:findup_mvvm/Pages/_Search/dialog_search_filter.dart';
import 'package:findup_mvvm/Pages/_User_Filter/item_detail_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ShowProductFilterPage extends StatefulWidget {
  SubCategoryModel subCategoryModel;
  GroupPlaceModel groupPlaceModel;

  ShowProductFilterPage({
    super.key,
    required this.subCategoryModel,
    required this.groupPlaceModel,
  });

  @override
  State<ShowProductFilterPage> createState() => _ShowProductFilterPageState();
}

class _ShowProductFilterPageState extends State<ShowProductFilterPage> {
  Helper helper = Helper();
  TextHelper textHelper = TextHelper();
  CheckScreen checkScreen = CheckScreen();
  ValueNotifier<bool> isListMode = ValueNotifier(false);
  String mode = '';

  void filterProduct({
    required ProductModelViewModel productModelViewModel,
    required int subPlaceID,
  }) async {
    await productModelViewModel.getProductFilter(
      userID: LocalStorage.userModel!.id,
      subCategoryID: widget.subCategoryModel.id,
      groupPlaceID: widget.groupPlaceModel.id,
      subPlaceID: subPlaceID,
    );
  }

  @override
  void initState() {
    // data for scroll
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      mode = await ShowModeStorage.getModeCache();

      Provider.of<SubPlaceViewModel>(
        context,
        listen: false,
      ).getSubPlace(groupPlaceID: widget.groupPlaceModel.id);

      Provider.of<ProductModelViewModel>(
        context,
        listen: false,
      ).getProductFilter(
        userID: LocalStorage.userModel!.id,
        subCategoryID: widget.subCategoryModel.id,
        groupPlaceID: widget.groupPlaceModel.id,
        subPlaceID: 0,
      );
      Provider.of<ProductModelViewModel>(context, listen: false).filterLatLong(
        userID: LocalStorage.userModel!.id,
        subCategoryID: widget.subCategoryModel.id,
        groupPlaceID: widget.groupPlaceModel.id,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    SlideViewModel slideViewModel=Provider.of<SlideViewModel>(context,listen: false);
    SubPlaceViewModel subPlaceViewModel = Provider.of<SubPlaceViewModel>(
      context,
    );
    ProductModelViewModel productModelViewModel =
        Provider.of<ProductModelViewModel>(context);
    Size size = MediaQuery.of(context).size;
    if (mode == 'list' || mode == '') {
      isListMode.value = true;
    } else {
      isListMode.value = false;
    }
    return Scaffold(
      backgroundColor: AppColor.backgroundColor,
      appBar: AppBar(
        centerTitle: false,
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: AppColor.appBarColor,
        title: Text(
          '${Translator.translate(widget.subCategoryModel.keyTranslate)}/${widget.groupPlaceModel.name}',

          style: textHelper.textAppBarStyle(
            color: AppColor.textAppBarColor,
            fontSize: 20,
          ),
        ),
        actions: [
          GestureDetector(
            onTap: () {
              helper.showScreenPopUp(
                context: context,
                title: "search_product",
                child: DialogSearchFilter(
                  title: "filter_product",
                  groupPlaceModel: widget.groupPlaceModel,
                  subCategoryModel: widget.subCategoryModel,
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.search, size: 28),
            ),
          ),
          GestureDetector(
            onTap: () {
              helper.showScreenPopUp(
                context: context,
                title: "All Product",
                child: Center(
                  child: Material(
                    color: Colors.transparent,
                    child: MapShowScreen(
                      listLatLong: productModelViewModel.listFilterLatLong,
                      groupPlaceModel: widget.groupPlaceModel,
                      subCategoryModel: widget.subCategoryModel,
                    ),
                  ),
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.map, size: 28),
            ),
          ),
        ],
      ),
      body: subPlaceViewModel.isLoading
          ? SimmerShowProductFilterElement(size: size)
          : SizedBox(
              width: size.width,
              height: size.height,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Slide ADS
                    Padding(
                      padding: const EdgeInsets.only(left: 8, top: 8, right: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildSlideAdvertise(
                            loadingPathTemp: 'assets/slide/top_slide1.png',
                            radius: 0,
                            imgList: [
                              slideViewModel.listSlideTop.first.imageUrl
                             
                            ],
                            height: checkScreen.isTablet(context)
                                ? (33 / 100) * size.height
                                : (25 / 100) * size.height,
                          ),
                          SizedBox(height: 10),
                          buildSubPlace(
                            onTab: (item) async {
                              filterProduct(
                                subPlaceID: item.id,
                                productModelViewModel: productModelViewModel,
                              );
                              subPlaceViewModel.subCategoryTab(
                                subPlaceModel: item,
                              );
                            },
                            listSubPlace: subPlaceViewModel.listSubPlace,
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: buildTopShow(
                        context: context,
                        listTopShow: productModelViewModel.listTopShowHomePage,
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.only(left: 8, right: 8),
                      child: productModelViewModel.listProductFilter.isEmpty
                          ? NoItemTextWidget()
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        right: 8,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            Translator.translate(
                                              widget
                                                  .subCategoryModel
                                                  .keyTranslate,
                                            ),
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        isListMode.value = !isListMode.value;
                                        if (mode == '' || mode == 'list') {
                                          ShowModeStorage.saveModeCache(
                                            mode: "grid",
                                          );
                                        } else {
                                          ShowModeStorage.saveModeCache(
                                            mode: "list",
                                          );
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: ValueListenableBuilder(
                                          valueListenable: isListMode,
                                          builder: (context, value, child) {
                                            return Icon(
                                              isListMode.value == false
                                                  ? Icons.view_list_sharp
                                                  : Icons.grid_view_outlined,
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                ValueListenableBuilder(
                                  valueListenable: isListMode,
                                  builder: (context, value, child) {
                                    return ListView.builder(
                                      physics:
                                          NeverScrollableScrollPhysics(), // disable inner scrolling
                                      shrinkWrap: true, // important!
                                      itemCount: productModelViewModel
                                          .listProductFilter
                                          .length,
                                      itemBuilder: (context, index) {
                                        ProductModel productModel =
                                            productModelViewModel
                                                .listProductFilter[index];
                                        List<String> images = helper
                                            .productModelSplitImage(
                                              product: productModel,
                                              path: 'property',
                                              context: context
                                            );
                                        return isListMode.value
                                            ? ListCardItem(
                                                productModel: productModel,
                                                onTap: () {
                                                  Navigation.goPage(
                                                    context: context,
                                                    page: ItemDetailPage(
                                                      productModel:
                                                          productModel,
                                                    ),
                                                  );
                                                },
                                              )
                                            : LargeCardItemElement(
                                                productModel: productModel,
                                                images: images,

                                                onTab: () {
                                                  Navigation.goPage(
                                                    context: context,
                                                    page: ItemDetailPage(
                                                      productModel:
                                                          productModel,
                                                    ),
                                                  );
                                                },
                                              );
                                      },
                                    );
                                  },
                                ),
                              ],
                            ),
                    ),

                    SizedBox(height: 50),
                  ],
                ),
              ),
            ),
    );
  }

  void showScreenPopUp({required BuildContext context, required String title}) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: "Map Dialog",
      barrierColor: Colors.black54, // background dim
      transitionDuration: const Duration(milliseconds: 500),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Center(child: DialogSearchAll(title: title));
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        final curvedValue = Curves.easeInOut.transform(animation.value) - 1.0;
        return Transform.translate(
          offset: Offset(0.0, curvedValue * -50), // slide from bottom
          child: Opacity(opacity: animation.value, child: child),
        );
      },
    );
  }

  Widget mapFloatingButton({
    required ProductModelViewModel productModelViewModel,
    required SubCategoryModel subCategoryModel,
    required GroupPlaceModel groupPlaceModel,
  }) {
    return GestureDetector(
      onTap: () {
        showGeneralDialog(
          context: context,
          barrierDismissible: true,
          barrierLabel: "Map Dialog",
          barrierColor: Colors.black54,
          transitionDuration: Duration(milliseconds: 400),
          pageBuilder: (context, animation, secondaryAnimation) {
            return Center(
              child: Material(
                color: Colors.transparent,
                child: MapShowScreen(
                  listLatLong: productModelViewModel.listFilterLatLong,
                  groupPlaceModel: groupPlaceModel,
                  subCategoryModel: subCategoryModel,
                ),
              ),
            );
          },
          transitionBuilder: (context, animation, secondaryAnimation, child) {
            final curved = Curves.easeOutBack.transform(animation.value);
            return Transform.scale(
              scale: curved,
              child: Opacity(opacity: animation.value, child: child),
            );
          },
        );
      },
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: LinearGradient(
            colors: [Color(0xff2E4A6B), Color(0xff1F3447)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 12,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Stack(
          children: [
            // blur glass layer
            ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
                child: Container(color: Colors.white.withOpacity(0.05)),
              ),
            ),

            Center(
              child: Icon(
                Icons.location_on_rounded,
                size: 30,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSlideAdvertise({
    required double height,
    required List<String> imgList,
    required double radius,
    required String loadingPathTemp,
  }) {
    return SlideAutoScrollElement(
      loadingPathTemp: loadingPathTemp,
      imagePaths: imgList,
      isAsset: false,
      interval: Duration(seconds: 10), // stay 4 seconds per slide
      slideDuration: Duration(milliseconds: 800), // slide animation speed
      hight: height,
      radius: radius,
    );
  }

  Widget horizontaCardProperty({
    required BuildContext context,
    required List<ProductModel> listProduct,
  }) {
    return BuildListHorizontalElement(
      child: Row(
        children: listProduct
            .map(
              (product) => SmallCardItemElement(
                onTab: () {
                  Navigation.goPage(
                    context: context,
                    page: ItemDetailPage(productModel: product),
                  );
                },
                imageUrl: helper
                    .productModelSplitImage(product: product, path: 'property',context: context)
                    .first,
                price: product.basePrice,
                billingPeriod: product.billingPeriod,
                title: product.title,
                location: '${product.groupPlace}.${product.subPlace}',
                discount: 'New',
                userProfileImage: product.userProfile,

                userName: product.userName,
                timeAgo: product.timeAgo,
                bathCount: product.bathCount,
                bedCount: product.bedCount,
                size: product.size,
              ),
            )
            .toList(),
      ),
    );
  }

  Widget buildSubPlace({
    required Function(SubPlaceModel) onTab,
    required List<SubPlaceModel> listSubPlace,
  }) {
    return BuildListHorizontalElement(
      child: Row(
        children: listSubPlace
            .map(
              (subPlace) => GestureDetector(
                onTap: () {
                  onTab(subPlace);
                },
                child: Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: subPlace.isSelected == 1
                            ? Colors.blue
                            : Colors.transparent,
                        width: 2,
                      ),
                      color: subPlace.isSelected == 1
                          ? Color(0xff344a58)
                          : AppColor.categoryBackgroundColor,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(
                        left: 12,
                        right: 12,
                        top: 11,
                        bottom: 11,
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            color: subPlace.isSelected == 1
                                ? Colors.white
                                : AppColor.activeIconColor,
                          ),
                          SizedBox(width: 2),
                          Text(
                            subPlace.name,
                            style: GoogleFonts.poppins(
                              color: subPlace.isSelected == 1
                                  ? Colors.white
                                  : AppColor.textCategoryColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Widget buildTopShow({
    required BuildContext context,
    required List<ProductModel> listTopShow,
  }) {
    return BuildListHorizontalElement(
      child: Row(
        children: listTopShow
            .map(
              (product) => SmallCardItemElement(
                onTab: () {
                  Navigation.goPage(
                    context: context,
                    page: ItemDetailPage(productModel: product),
                  );
                },
                imageUrl: helper
                    .productModelSplitImage(product: product, path: 'property',context: context)
                    .first,
                price: product.basePrice,
                billingPeriod: product.billingPeriod,
                title: product.title,
                location: '${product.groupPlace}.${product.subPlace}',
                discount: 'New',
                userProfileImage: product.userProfile,

                userName: product.userName,
                timeAgo: product.timeAgo,
                bathCount: product.bathCount,
                bedCount: product.bedCount,
                size: product.size,
              ),
            )
            .toList(),
      ),
    );
  }
}
