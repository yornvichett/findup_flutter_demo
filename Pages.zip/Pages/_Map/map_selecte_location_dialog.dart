import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/constants/text_helper.dart';
import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapSelecteLocationScreen extends StatefulWidget {
  double defaultLat;
  double defaultLon;
  Function(Map<String, dynamic> mapSelectedLatLong) selectedCalBack;
  MapSelecteLocationScreen({
    super.key,
    required this.selectedCalBack,
    required this.defaultLat,
    required this.defaultLon,
  });

  @override
  State<MapSelecteLocationScreen> createState() =>
      _MapSelecteLocationScreenState();
}

class _MapSelecteLocationScreenState extends State<MapSelecteLocationScreen> {
  GoogleMapController? _controller;
  TextHelper textHelper = TextHelper();

  List<Map<String, dynamic>> mapSelectedLocation = [
    {"name": "", "lat": 11.5564, "lng": 104.9282},
  ];
  double latTemp = 0.00;
  double lonTemp = 0.00;

  // Sample list of lat/lng

  late Set<Marker> _markers;
  ValueNotifier<bool> mapRefresh = ValueNotifier(false);

  static const CameraPosition _initialPosition = CameraPosition(
    target: LatLng(11.5564, 104.9282),
    zoom: 12,
  );

  @override
  void initState() {
    _markers = mapSelectedLocation.map((loc) {
      return Marker(
        icon: AssetMapBitmap('assets/icons/remark_icon.png', width: 40),
        markerId: MarkerId(''),
        position: LatLng(widget.defaultLat, widget.defaultLon),
      );
    }).toSet();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: mapRefresh,
      builder: (context, value, child) {
        return Material(
          child: Stack(
            children: [
              GoogleMap(
                mapType: MapType.hybrid,
                buildingsEnabled: true,
                trafficEnabled: false,
                indoorViewEnabled: true,
                initialCameraPosition: _initialPosition,
                onMapCreated: (controller) => _controller = controller,
                myLocationEnabled: true,
                myLocationButtonEnabled: true,
                zoomControlsEnabled: true,
                markers: _markers,
                onTap: (LatLng position) {
                  latTemp = position.latitude;
                  lonTemp = position.longitude;

                  _markers = {
                    Marker(
                      icon: AssetMapBitmap(
                        'assets/icons/remark_icon.png',
                        width: 40,
                      ),
                      markerId: const MarkerId("selected_location"),
                      position: position,
                    ),
                  };
                  mapRefresh.value = !mapRefresh.value;
                },
              ),
              Positioned(
                bottom: 10,

                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () async {
                          latTemp = 0.00;
                          lonTemp = 0.00;
                          widget.selectedCalBack({
                            'lat': latTemp,
                            'lon': lonTemp,
                          });
                          List<Placemark> placemarks =
                              await placemarkFromCoordinates(latTemp, lonTemp);
                          Placemark place = placemarks.first;

                          print("Country: ${place.country}");
                          print("City: ${place.locality}");
                          print("Street: ${place.street}");
                          print(
                            "Full Address: ${place.name}, ${place.street}, ${place.locality}, ${place.country}",
                          );
                          Navigator.pop(context);
                        },
                        child: Container(
                          width: 100,
                          height: 40,

                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Center(
                            child: Text(
                              'Clear',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 20),
                      GestureDetector(
                        onTap: () {
                          widget.selectedCalBack({
                            'lat': latTemp,
                            'lon': lonTemp,
                          });
                          Navigator.pop(context);
                        },
                        child: Container(
                          width: 100,
                          height: 40,

                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Center(
                            child: Text(
                              'Confirm',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget bottomAppBar() {
    return BottomAppBar(
      height: 100,
      color: Colors.white,
      child: Row(children: [Container(width: 100, color: Colors.black)]),
    );
  }
}
