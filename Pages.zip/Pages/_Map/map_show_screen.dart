import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/constants/text_helper.dart';
import 'package:findup_mvvm/Core/services/helper.dart';
import 'package:findup_mvvm/Core/services/translate.dart';
import 'package:findup_mvvm/Core/utils/drop_down_search_element.dart';
import 'package:findup_mvvm/Data/models/group_place_model.dart';
import 'package:findup_mvvm/Data/models/product_model.dart';
import 'package:findup_mvvm/Data/models/sub_category_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';

class MapShowScreen extends StatefulWidget {
  final List<ProductModel> listLatLong;
  GroupPlaceModel groupPlaceModel;
  SubCategoryModel subCategoryModel;

   MapShowScreen({super.key, required this.listLatLong,required this.groupPlaceModel,required this.subCategoryModel});

  @override
  State<MapShowScreen> createState() => _MapShowScreenState();
}

class _MapShowScreenState extends State<MapShowScreen> {
  GoogleMapController? _controller;
  TextHelper textHelper = TextHelper();

  ValueNotifier<bool> refersh = ValueNotifier(false);
  Helper helper = Helper();

  BitmapDescriptor? _remarkIcon;
  Set<Marker> _markers = {};

  static const CameraPosition _initialPosition = CameraPosition(
    target: LatLng(11.5564, 104.9282), // Phnom Penh
    zoom: 12,
  );

  @override
  void initState() {
    super.initState();
    _setMarkers();
  }

  AssetMapBitmap assetMapBitmap = AssetMapBitmap(
    'assets/icons/remark_icon.png',
    width: 40,
  );
  void _setMarkers() {
    final markers = widget.listLatLong.map((loc) {
      return Marker(
        markerId: MarkerId(loc.id.toString()),
        position: LatLng(loc.lat, loc.lon),
        icon: assetMapBitmap,
        onTap: () async {
          // Fetch product data smoothly
          await context.read<ProductModelViewModel>().getProductByID(
            productID: loc.id,
          );
          refersh.value = !refersh.value;
        },
      );
    }).toSet();

    setState(() {
      _markers = markers;
    });
  }

  @override
  Widget build(BuildContext context) {
    final productModelViewModel = Provider.of<ProductModelViewModel>(
      context,
      listen: false,
    );

    return SafeArea(
      child: Material(
        child: Column(
          children: [
            // ✅ Map isolated in its own Expanded widget
            Expanded(child: _buildMap(context: context)),

            // ✅ Smooth bottom info card
            ValueListenableBuilder(
              valueListenable: refersh,
              builder: (context, value, child) {
                final list = productModelViewModel.listGetProductByID;
                if (list.isEmpty) return const SizedBox.shrink();
                return AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: bottomInfo(
                    productModel: list.first,
                    onHideForm: () {
                      productModelViewModel.listGetProductByID = [];
                      refersh.value = !refersh.value;
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  /// ✅ Separate map widget to prevent rebuild lag
  Widget _buildMap({required BuildContext context}) {
    Size size = MediaQuery.of(context).size;
    return Stack(
      children: [
        GoogleMap(
          mapType: MapType.hybrid,
          buildingsEnabled: true,
          trafficEnabled: false,
          indoorViewEnabled: true,
          initialCameraPosition: _initialPosition,
          onMapCreated: (controller) => _controller = controller,
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          zoomControlsEnabled: true,
          liteModeEnabled: false,
          markers: _markers,
        ),

        // ✅ FIXED: search box positioned correctly
        //Positioned(top: 10, left: 8, right: 8, child: DropDownSearchElement()),

        // ✅ close button
        Positioned(
          right: 10,
          top: 10,
          child: Container(
            width: size.width,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Container(
                    color: const Color.fromARGB(160, 0, 0, 0),
                    child: Padding(
                      padding:  EdgeInsets.all(8.0),
                      child: Text('${widget.groupPlaceModel.name.toString()} > ${Translator.translate(widget.subCategoryModel.keyTranslate)}',style: TextStyle(color: Colors.white),),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                      border: Border.all(color: Colors.red.shade300, width: 3),
                    ),
                    child: Icon(
                      Icons.arrow_drop_down_outlined,
                      color: Colors.red.shade300,
                      size: 29,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// ✅ Optimized bottom panel
  Widget bottomInfo({
    required ProductModel productModel,
    required Function() onHideForm,
  }) {
    List<String> listImage = helper.productModelSplitImage(
      path: 'property',
      product: productModel,
      context: context
    );

    return GestureDetector(
      onTap: () {
          helper.showItemPopupDetail(context: context,productModel: productModel);
      },
      child: Container(
        key: ValueKey(productModel.id),
        height: 150,
        decoration: const BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              offset: Offset(0, -2),
              blurRadius: 6,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              // ✅ Left image carousel
              Stack(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: Colors.black12,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    clipBehavior: Clip.hardEdge,
                    child: CarouselSlider(
                      options: CarouselOptions(
                        height: 120,
                        viewportFraction: 1.0,
                        enableInfiniteScroll: listImage.length > 1,
                        enlargeCenterPage: false,
                        autoPlay: true, // ✅ AUTO SCROLL
                        autoPlayInterval: Duration(seconds: 3),
                        autoPlayAnimationDuration: Duration(milliseconds: 800),
                      ),
                      items: listImage.map((imgUrl) {
                        return CachedNetworkImage(
                          imageUrl: imgUrl,
                          fit: BoxFit.cover,
                          width: 120,
                          height: 120,
                          placeholder: (context, url) =>
                              const Center(child: CircularProgressIndicator()),
                          errorWidget: (context, url, error) =>
                              const Icon(Icons.broken_image, color: Colors.grey),
                        );
                      }).toList(),
                    ),
                  ),
      
                  GestureDetector(
                    onTap: () {
                      onHideForm();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Icon(Icons.cancel),
                    ),
                  ),
                ],
              ),
      
              const SizedBox(width: 10),
      
              // ✅ Right product info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      productModel.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      productModel.subTitle,
                      style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.location_city, color: Colors.grey, size: 16),
                        Text(
                          '${productModel.groupPlace} > ${productModel.subPlace}',
                          style: TextStyle(color: Colors.grey, fontSize: 12,),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "\$${productModel.basePrice}${productModel.billingPeriod}",
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
