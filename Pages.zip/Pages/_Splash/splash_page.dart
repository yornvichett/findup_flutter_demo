import 'package:findup_mvvm/Core/Storage/pref_storage.dart';
import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:findup_mvvm/Core/services/local_storage.dart';
import 'package:findup_mvvm/Core/services/translate.dart';
import 'package:findup_mvvm/Data/models/user_model.dart';
import 'package:findup_mvvm/Data/view_models/app_config_view_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:findup_mvvm/Firebase/firebase_service.dart';
import 'package:findup_mvvm/Pages/_Home/home_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'package:flutter/material.dart';


import 'package:provider/provider.dart';


class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  PrefStorage prefStorage = PrefStorage();
  String lang = "km.txt";



  void initLanguage() {
    String keyLan = prefStorage.langKey;
    prefStorage
        .initLanguages(key: keyLan)
        .then((value) {
          if (value.isNotEmpty) {
            lang = value['lan_code'] + '.txt';
          }
        })
        .whenComplete(() async {
          await Translator.load('assets/lang/$lang');
        });
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      FirebaseMessaging.instance.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );

      context.read<AppConfigViewModel>().getAppConfig();
      context.read<ProductModelViewModel>().getAllLatLong();
    });
    initLanguage();
    LocalStorage.getMap('user').then((value) async {
      if (value != null) {
        LocalStorage.userModel = UserModel.fromJson(value);
      } else {
        FirebaseService.logout();
      }
    });
    LocalStorage.getMap('api_token').then((value) async {
      if (value != null) {
        LocalStorage.apiToken = value['api_token'];
      } else {
        FirebaseService.logout();
      }
    });

    Future.delayed(const Duration(seconds: 3), () {
      // Here you can write your code

      setState(() {
        Navigation.goReplacePage(context: context, page: HomePage());
      });
    });
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xfff7f7f8),
      body: Container(
        width: size.width,
        height: size.height,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background/bg3.png'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.blue.withOpacity(
                0.1,
              ), // 0.0 = fully transparent, 1.0 = normal
              BlendMode.modulate,
            ),
          ),
        ),
        child: Center(child: Image.asset('assets/images/findUp.png')),
      ),
    );
  }
}
