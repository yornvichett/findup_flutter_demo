import 'package:flutter/material.dart';

class YourContactPage extends StatefulWidget {
  const YourContactPage({super.key});

  @override
  State<YourContactPage> createState() => _YourContactPageState();
}

class _YourContactPageState extends State<YourContactPage> {
  Map<String, bool> switchValues = {
    "Phone Number": false,
    "Telegram": false,
    "Email": false,
    "WhatsApp": false,
  };

  Map<String, String> contactValues = {
    "Phone Number": "",
    "Telegram": "",
    "Email": "",
    "WhatsApp": "",
  };

  Future<void> showInputDialog(String title) async {
    TextEditingController controller =
        TextEditingController(text: contactValues[title]);

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Enter $title"),
          content: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: "Type $title here...",
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  contactValues[title] = controller.text;
                });
                Navigator.pop(context);
              },
              child: Text("Save"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Your Contact"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: switchValues.keys.map((title) {
          return Card(
            elevation: 2,
            margin: const EdgeInsets.only(bottom: 14),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        title,
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Switch(
                        value: switchValues[title]!,
                        onChanged: (value) async {
                          setState(() {
                            switchValues[title] = value;
                          });

                          if (value == true) {
                            await showInputDialog(title);

                            // If user didn't type anything → keep switch off
                            if (contactValues[title]!.isEmpty) {
                              setState(() => switchValues[title] = false);
                            }
                          } else {
                            setState(() {
                              contactValues[title] = "";
                            });
                          }
                        },
                      ),
                    ],
                  ),

                  if (contactValues[title]!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 5, left: 5),
                      child: Text(
                        contactValues[title]!,
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                    ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
