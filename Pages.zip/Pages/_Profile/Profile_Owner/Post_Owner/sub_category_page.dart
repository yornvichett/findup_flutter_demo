// import 'package:findup_mvvm/Core/Storage/refresh_storage.dart';
// import 'package:findup_mvvm/Core/constants/app_color.dart';
// import 'package:findup_mvvm/Core/navigation/navigation.dart';
// import 'package:findup_mvvm/Core/services/translate.dart';
// import 'package:findup_mvvm/Data/models/group_category_model.dart';
// import 'package:findup_mvvm/Data/models/sub_category_model.dart';
// import 'package:findup_mvvm/Data/view_models/refresh_version_view_model.dart';

// import 'package:findup_mvvm/Data/view_models/sub_category_view_modle.dart';

// import 'package:findup_mvvm/Pages/_Profile/Profile_Owner/Post_Owner/group_place_page.dart';

// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:provider/provider.dart';

// class SubCategoryPage extends StatefulWidget {
//   GroupCategoryModel groupCategoryModel;
//   String saleType;
//   bool allowSubCategoryRefresh;
//   int serverVersion;
//   SubCategoryPage({
//     super.key,
//     required this.groupCategoryModel,
//     required this.saleType,
//     required this.allowSubCategoryRefresh,
//     required this.serverVersion,
//   });

//   @override
//   State<SubCategoryPage> createState() => _SubCategoryPageState();
// }

// class _SubCategoryPageState extends State<SubCategoryPage> {
//   RefreshVersionViewModel refreshVersionViewModel = RefreshVersionViewModel();
//   Map<String, dynamic> localGroupPlaceVersion = {};
//   bool allowGroupPlaceRefresh=false;
//   ValueNotifier<bool> refreshPage=ValueNotifier(false);
//   @override
//   void initState() {
//     super.initState();

//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       refreshVersionViewModel.getRefreshVersion();
//       RefreshStorage.getGroupPlaceVersion().then((value) {
//         localGroupPlaceVersion = value;
        
//       });
//       if (widget.allowSubCategoryRefresh) {
//         Provider.of<SubCategoryViewModle>(
//           context,
//           listen: false,
//         ).getSubcategory(groupCategoryID: widget.groupCategoryModel.id);
//         RefreshStorage.saveSubCategoryVersion(version: widget.serverVersion);
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     SubCategoryViewModle subCategoryViewModle =
//         Provider.of<SubCategoryViewModle>(context);
//     // save list to storage
//     if (widget.allowSubCategoryRefresh) {
//       RefreshStorage.saveListSubCategory(
//         listData: subCategoryViewModle.listSubCategoryView,
//       );
//     } else {
//       refreshPage.value=false;
//       RefreshStorage.getListSubCategory().then((value) {
//         subCategoryViewModle.listSubCategoryView = value;
//         refreshPage.value=true;
//       });
//     }
//     return Scaffold(
//       backgroundColor: Colors.grey[100],
//       appBar: AppBar(
//         backgroundColor: AppColor.appBarColor,
//         elevation: 0.5,
//         centerTitle: true,
//         title: Text(
//           Translator.translate(widget.groupCategoryModel.keyTranslate),

//           style: GoogleFonts.poppins(
//             fontWeight: FontWeight.bold,
//             color: AppColor.textAppBarColor,
//           ),
//         ),
//         iconTheme: const IconThemeData(color: Colors.white),
//       ),
//       body: ValueListenableBuilder(
//         valueListenable: refreshPage,
//         builder: (context, value, child) {
//           return subCategoryViewModle.isLoading
//               ? Center(child: CircularProgressIndicator())
//               : ListView.builder(
//                   itemCount: subCategoryViewModle.listSubCategoryView.length,
//                   itemBuilder: (context, index) {
//                     SubCategoryModel subCategoryModel =
//                         subCategoryViewModle.listSubCategoryView[index];
          
//                     return listItemWidget(
//                       subCategoryModel: subCategoryModel,
          
//                       onTab: () {
//                         int serverVersion=refreshVersionViewModel.listRefreshVersionModel.first.groupPlaceRefreshVersion;
//                         int localVersion=localGroupPlaceVersion['version'];
//                         if(serverVersion>localVersion){
//                           allowGroupPlaceRefresh=true;
//                         }else{
//                           allowGroupPlaceRefresh=false;
//                         }
//                         Navigation.goPage(
//                           context: context,
//                           page: GroupPlacePage(
//                             groupCategoryModel: widget.groupCategoryModel,
                            
//                             saleType: widget.saleType,
//                             allowGroupPlaceRefresh: allowGroupPlaceRefresh,
//                             serverVersion: serverVersion,
//                           ),
//                         );
//                       },
//                     );
//                   },
//                 );
//         }
//       ),
//     );
//   }

//   Widget listItemWidget({
//     required SubCategoryModel subCategoryModel,
//     Function()? onTab,
//   }) {
//     return GestureDetector(
//       onTap: onTab,
//       child: Container(
//         height: 60,
//         decoration: BoxDecoration(
//           border: Border(
//             bottom: BorderSide(
//               color: const Color.fromARGB(66, 0, 0, 0),
//               width: 0.5,
//             ),
//           ),
//         ),
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(
//                 Translator.translate(subCategoryModel.keyTranslate),

//                 style: GoogleFonts.poppins(fontSize: 18),
//               ),
//               Icon(Icons.arrow_right),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
