import 'dart:convert';
import 'dart:io';

import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/services/editable_image.dart';
import 'package:findup_mvvm/Core/services/helper.dart';
import 'package:findup_mvvm/Core/services/local_storage.dart';
import 'package:findup_mvvm/Core/utils/animation_pop_up_element.dart';
import 'package:findup_mvvm/Core/utils/sub_category_picker_sheet_element.dart';
import 'package:findup_mvvm/Data/models/group_category_model.dart';
import 'package:findup_mvvm/Data/models/group_place_model.dart';
import 'package:findup_mvvm/Data/models/product_model.dart';
import 'package:findup_mvvm/Data/models/sub_category_model.dart';
import 'package:findup_mvvm/Data/models/sub_place_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:findup_mvvm/Data/view_models/sub_place_view_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class EditPage extends StatefulWidget {
  final String saleType;
  ProductModel productDefaultParam;
  EditPage({
    super.key,
    required this.saleType,
    required this.productDefaultParam,
  });

  @override
  State<EditPage> createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  final _formKey = GlobalKey<FormState>();
  final picker = ImagePicker();

  // Controllers
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _subTitleController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _sizeController = TextEditingController();
  final TextEditingController _bedroomController = TextEditingController();
  final TextEditingController _bathroomController = TextEditingController();
  final TextEditingController _buillingPerioudController =
      TextEditingController(text: 'month');
  List<String> defaultImage = [];
  Helper helper = Helper();
  List<File> selectedImages=[];

  bool _isSubmitting = false; // 👈 add this
  List<EditableImage> images = [];

  Future<void> _pickImages() async {
    final pickedFiles = await picker.pickMultiImage(
      imageQuality: 50,
      maxWidth: 800,
      maxHeight: 800,
    );
    if (pickedFiles != null) {
      setState(() {
        selectedImages.addAll(pickedFiles.map((e) => File(e.path)));
      });
    }
  }

  void _clearForm() {
    setState(() {
      _titleController.clear();
      _subTitleController.clear();
      _priceController.clear();
      _sizeController.clear();
      _bedroomController.clear();
      _bathroomController.clear();
      images.clear();
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PropertySuccessPopup(
        onProcess: () async {
          await Future.delayed(const Duration(seconds: 3));
        },
      ),
    );
  }

  void _editSubmit({
    required ProductModelViewModel productModelViewModel,
  }) async {
    if (_formKey.currentState!.validate()) {
      final Map<String, dynamic> jsonBody = {
        'user_id': LocalStorage.userModel?.id,
        'user_name': LocalStorage.userModel?.name,
        'product_id': widget.productDefaultParam.id,
        'title': _titleController.text.trim(),
        'sub_title': _subTitleController.text.trim(),
        'base_price': double.parse(_priceController.text.trim()),
        'billing_period': widget.saleType.toLowerCase() == 'rent'
            ? '/${_buillingPerioudController.text.trim()}'
            : '',
        'size': _sizeController.text.trim(),
        'bed_count': int.parse(_bedroomController.text.trim()),
        'bath_count': int.parse(_bathroomController.text.trim()),
      };

      // You can upload even if no new files (since old ones exist)
      final success = await productModelViewModel.editProduct(
        jsonBody: jsonBody,
        userID: LocalStorage.userModel!.id,
        images: selectedImages,
        oldFileName: widget.productDefaultParam.imageList,
        context: context
      );

      if (mounted) setState(() => _isSubmitting = false);

      if (success) {
        _clearForm();
      } else {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => PropertySuccessPopup(
            icon: Icons.error,
            iconColor: Colors.red,
            message: 'Failed Upload',
            onProcess: () async {
              await Future.delayed(const Duration(seconds: 3));
            },
          ),
        );
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _titleController.text = widget.productDefaultParam.title;
    _subTitleController.text = widget.productDefaultParam.subTitle;
    _priceController.text = widget.productDefaultParam.basePrice.toString();
    _sizeController.text = widget.productDefaultParam.size;
    _bedroomController.text = widget.productDefaultParam.bedCount.toString();
    _bathroomController.text = widget.productDefaultParam.bathCount.toString();
    _buillingPerioudController.text = widget.productDefaultParam.billingPeriod;
    defaultImage = helper.productModelSplitImage(
      product: widget.productDefaultParam,
      path: 'property',
      context: context
    );
    images = defaultImage.map((url) => EditableImage(url: url)).toList();
  }

  @override
  Widget build(BuildContext context) {
    ProductModelViewModel productModelViewModel =
        Provider.of<ProductModelViewModel>(context);

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          'Edit',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            color: AppColor.textAppBarColor,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        backgroundColor: AppColor.appBarColor,
      ),

      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Stack(
          children: [
            AbsorbPointer(
              absorbing: _isSubmitting, // 👈 disables all user actions
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionTitle("Basic Info (${widget.saleType})"),
                      _buildTextField("Title", _titleController),
                      _buildTextField(
                        "Description",
                        _subTitleController,
                        maxLines: 3,
                      ),
                      const SizedBox(height: 10),

                      const SizedBox(height: 10),
                      _sectionTitle("Details"),
                      widget.saleType.toLowerCase() == 'rent'
                          ? _buildPriceWithBillingPeriod(_priceController)
                          : _buildTextField(
                              "Total price (\$)",
                              _priceController,
                              keyboardType: TextInputType.numberWithOptions(),
                            ),
                      _buildTextField("Size", _sizeController),
                      Row(
                        children: [
                          Expanded(
                            child: _buildTextField(
                              "Bedrooms",
                              _bedroomController,
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _buildTextField(
                              "Bathrooms",
                              _bathroomController,
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _sectionTitle("Images"),
                      GestureDetector(
                        onTap: _pickImages,
                        child: Container(
                          height: 150,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: images.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(width: 8),
                            itemBuilder: (context, i) {
                              final img = images[i];
                              return Stack(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: img.isNetwork
                                        ? Image.network(
                                            img.url!,
                                            width: 120,
                                            height: 120,
                                            fit: BoxFit.cover,
                                          )
                                        : Image.file(
                                            img.file!,
                                            width: 120,
                                            height: 120,
                                            fit: BoxFit.cover,
                                          ),
                                  ),
                                  Positioned(
                                    top: 4,
                                    right: 4,
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          images.removeAt(i); // delete image
                                        });
                                      },
                                      child: Container(
                                        decoration: const BoxDecoration(
                                          color: Colors.black54,
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(
                                          Icons.close,
                                          size: 20,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      ElevatedButton(
                        onPressed: () {
                          _editSubmit(
                            productModelViewModel: productModelViewModel,
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColor.appBarColor,
                          minimumSize: const Size(double.infinity, 56),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: Text(
                          productModelViewModel.isLoading
                              ? 'Uploading...'
                              : "Edit Property",
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // 🌀 Overlay loading animation
            if (_isSubmitting)
              Container(
                color: Colors.black.withOpacity(0.4),
                child: const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Colors.green),
                      SizedBox(height: 12),
                      Text(
                        "Uploading property...",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {

      //   },
      //   backgroundColor: Colors.tealAccent.shade700,
      //   elevation: 8,
      //   splashColor: Colors.white.withOpacity(0.2),
      //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
      //   child: const Icon(
      //     Icons.location_on_rounded,
      //     color: Colors.white,
      //     size: 32,
      //   ),
      // ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Text(
      text,
      style: GoogleFonts.poppins(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: Colors.black87,
      ),
    ),
  );

  Widget _buildPriceWithBillingPeriod(TextEditingController priceController) {
    List<String> billingPeriods = ['month', 'year', 'week', 'Custom'];
    String selectedPeriod = 'month';
    String? customValue;

    return StatefulBuilder(
      builder: (context, setState) {
        Future<void> _showCustomInputDialog() async {
          final TextEditingController customController = TextEditingController(
            text: customValue ?? '',
          );
          await showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) {
              return Padding(
                padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom,
                  left: 16,
                  right: 16,
                ),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 10,
                        offset: const Offset(0, -2),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Enter custom billing period',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: customController,
                        autofocus: true,
                        decoration: InputDecoration(
                          hintText: 'period',
                          filled: true,
                          fillColor: Colors.grey.shade100,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.pop(context),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 14,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              child: const Text('Cancel'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                final entered = customController.text.trim();
                                if (entered.isNotEmpty) {
                                  setState(() {
                                    customValue = entered;
                                    _buillingPerioudController.text =
                                        customValue!.trim();
                                    if (!billingPeriods.contains(entered)) {
                                      billingPeriods.insert(
                                        billingPeriods.length - 1,
                                        entered,
                                      );
                                    }
                                    selectedPeriod = entered;
                                  });
                                  Navigator.pop(context);
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blueAccent,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 14,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              child: const Text(
                                'Save',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }

        return Row(
          children: [
            Expanded(
              flex: 2,
              child: _buildTextField(
                "Total price (\$)",
                priceController,
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.grey.shade300),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.shade200,
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: selectedPeriod,
                      isExpanded: true,
                      icon: const Icon(Icons.keyboard_arrow_down_rounded),
                      style: const TextStyle(fontSize: 15),
                      dropdownColor: Colors.white,
                      onChanged: (newValue) async {
                        if (newValue == 'Custom') {
                          await _showCustomInputDialog();
                        } else {
                          setState(() {
                            selectedPeriod = newValue!;
                            _buillingPerioudController.text = selectedPeriod
                                .trim();
                          });
                        }
                      },
                      items: billingPeriods.map((period) {
                        return DropdownMenuItem<String>(
                          value: period,
                          child: Text(
                            period == 'Custom' ? 'Custom...' : period,
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                              color: Colors.black,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTextField(
    String label,

    TextEditingController controller, {

    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,

        validator: (value) =>
            value == null || value.isEmpty ? 'Please enter $label' : null,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
