// import 'package:findup_mvvm/Core/Storage/pref_storage.dart';
// import 'package:findup_mvvm/Core/navigation/navigation.dart';
// import 'package:findup_mvvm/Core/services/translate.dart';
// import 'package:findup_mvvm/Data/view_models/user_view_model.dart';
// import 'package:findup_mvvm/Pages/_Splash/splash_page.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// class UserInfoRegister extends StatefulWidget {
//   const UserInfoRegister({super.key});

//   @override
//   State<UserInfoRegister> createState() => _UserInfoRegisterState();
// }

// class _UserInfoRegisterState extends State<UserInfoRegister> {
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController phoneController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

 

//   final _formKey = GlobalKey<FormState>();

//   // Brand Colors
//   final Color blueStart = const Color(0xFF4FA3FF); // light blue
//   final Color blueEnd = const Color(0xFF002F6C); // dark blue
//   final Color orange = const Color(0xFFFF6A00);
//   PrefStorage prefStorage = PrefStorage();
//   bool _obscurePassword = true;

//   void registeruser({
//     required UserViewModel userViewModel,
//     required String userName,
//     required String phoneNumber,
//     required String password,
//   }) async {
//     String fcmTokenKey = await prefStorage.getFCMToken();
//     userViewModel.userModel = await userViewModel.continueWithUserInfo(

//       phoneNumber: phoneNumber,
//       name: userName,
//       email: 'none',
//       userProfile: '',
//       password: password,
//       confirmPassword: password,
//       fcmToken: fcmTokenKey,
//     );

//     Navigation.goReplacePage(context: context, page: const SplashPage());
//   }

//   @override
//   Widget build(BuildContext context) {
//     final userViewModel = Provider.of<UserViewModel>(context);
//     return Scaffold(
//       resizeToAvoidBottomInset: false,
//       appBar: AppBar(
//         backgroundColor: blueStart,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       body: GestureDetector(
//         onTap: () {
//           FocusScope.of(context).unfocus();
//         },
//         child: Container(
//           width: double.infinity,
//           height: double.infinity,

//           /// 🔥 Beautiful Gradient Backgrounda
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: [blueStart, blueEnd],
//             ),
//             image: DecorationImage(
//               image: AssetImage('assets/background/bg3.png'),
//               fit: BoxFit.cover,
//               colorFilter: ColorFilter.mode(
//                 Color.fromARGB(
//                   107,
//                   0,
//                   47,
//                   108,
//                 ).withOpacity(0.1), // change opacity level here
//                 BlendMode.srcATop,
//               ),
//             ),
//           ),

//           child: SingleChildScrollView(
//             padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
//             child: Form(
//               key: _formKey,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   /// Title
//                    Text(
//                     Translator.translate('user_personal_information'),
//                     style: TextStyle(
//                       fontSize: 28,
//                       fontWeight: FontWeight.bold,
//                       color: Colors.white,
//                     ),
//                   ),
//                   const SizedBox(height: 8),

//                   Text(
//                     Translator.translate('enter_your_personal_information'),
//                     style: TextStyle(fontSize: 16, color: Colors.white70),
//                   ),
//                   const SizedBox(height: 40),

//                   /// Name Input
//                   TextFormField(
//                     controller: nameController,
//                     style: TextStyle(color: Colors.white),
//                     decoration: InputDecoration(
//                       labelText: Translator.translate('full_name'),
//                       labelStyle: const TextStyle(color: Colors.white),
//                       prefixIcon: const Icon(Icons.person, color: Colors.white),
//                       filled: true,
//                       fillColor: Colors.white.withOpacity(0.18),
//                       focusedBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(14),
//                         borderSide: const BorderSide(color: Colors.white),
//                       ),
//                       enabledBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(14),
//                         borderSide: BorderSide(
//                           color: Colors.white.withOpacity(0.3),
//                         ),
//                       ),
//                     ),
//                     validator: (value) {
//                       if (value == null || value.isEmpty) {
//                         return Translator.translate('please_enter_your_name');
//                       }
//                       return null;
//                     },
//                   ),
//                   const SizedBox(height: 20),

//                   /// Phone Input
//                   TextFormField(
//                     controller: phoneController,
//                     keyboardType: TextInputType.phone,
//                     style:  TextStyle(color: Colors.white),
//                     decoration: InputDecoration(
//                       labelText: Translator.translate('phone_number'),
//                       labelStyle: const TextStyle(color: Colors.white),
//                       prefixIcon: const Icon(Icons.phone, color: Colors.white),
//                       filled: true,
//                       fillColor: Colors.white.withOpacity(0.18),
//                       focusedBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(14),
//                         borderSide: const BorderSide(color: Colors.white),
//                       ),
//                       enabledBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(14),
//                         borderSide: BorderSide(color: Colors.white54),
//                       ),
//                     ),
//                     validator: (value) {
//                       if (value == null || value.isEmpty) {
//                         return Translator.translate('please_enter_your_phone_number');
//                       }
//                       if (value.length < 8) {
//                         return Translator.translate('phone_number_too_short');
//                       }
//                       return null;
//                     },
//                   ),
//                   const SizedBox(height: 20),

//                   /// Phone Input
//                   TextFormField(
//                     controller: passwordController,
//                     keyboardType: TextInputType.visiblePassword,
//                     obscureText: _obscurePassword,
//                     style: const TextStyle(color: Colors.white),

//                     decoration: InputDecoration(
//                       labelText: Translator.translate('password'),
//                       labelStyle: const TextStyle(color: Colors.white),
//                       prefixIcon: const Icon(Icons.lock, color: Colors.white),

//                       /// 👁 Eye Icon
//                       suffixIcon: IconButton(
//                         icon: Icon(
//                           _obscurePassword
//                               ? Icons.visibility_off
//                               : Icons.visibility,
//                           color: Colors.white,
//                         ),
//                         onPressed: () {
//                           setState(() {
//                             _obscurePassword = !_obscurePassword;
//                           });
//                         },
//                       ),

//                       filled: true,
//                       fillColor: Colors.white.withOpacity(0.18),

//                       focusedBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(14),
//                         borderSide: const BorderSide(color: Colors.white),
//                       ),
//                       enabledBorder: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(14),
//                         borderSide: BorderSide(color: Colors.white54),
//                       ),
//                     ),

//                     validator: (value) {
//                       if (value == null || value.isEmpty) {
//                         return Translator.translate('please_enter_your_password');
//                       }
//                       if (value.length < 6) {
//                         return Translator.translate('password_too_short');
//                       }
//                       return null;
//                     },
//                   ),

//                   const SizedBox(height: 40),

//                   /// Orange Button
//                   SizedBox(
//                     width: double.infinity,
//                     child: ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: orange,
//                         padding: const EdgeInsets.symmetric(vertical: 16),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(16),
//                         ),
//                         elevation: 8,
//                       ),
//                       onPressed: () {
//                         if (_formKey.currentState!.validate()) {
//                           registeruser(
                         
//                             userViewModel: userViewModel,
//                             userName: nameController.text.trim(),
//                             phoneNumber: phoneController.text.trim(),
//                             password: passwordController.text.trim(),
//                           );
//                           // ScaffoldMessenger.of(context).showSnackBar(
//                           //   const SnackBar(content: Text("Register Success")),
//                           // );
//                         }
//                       },
//                       child: Text(
//                         Translator.translate("continue"),
//                         style: TextStyle(
//                           fontSize: 18,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.white,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
