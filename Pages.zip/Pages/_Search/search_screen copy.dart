import 'dart:async';

import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:findup_mvvm/Core/services/local_storage.dart';
import 'package:findup_mvvm/Core/utils/product_item_card.dart';
import 'package:findup_mvvm/Data/models/product_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:findup_mvvm/Pages/_User_Filter/item_detail_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';



class SearchScreen extends StatefulWidget {
  final String title;

  const SearchScreen({super.key, required this.title});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  Timer? _debounce;

  static const int _pageSize = 20;

  @override
  void initState() {
    super.initState();

    // Scroll listener for pagination
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    final vm = Provider.of<ProductModelViewModel>(context, listen: false);

    // Cancel previous timer
    if (_debounce?.isActive ?? false) _debounce!.cancel();

    _debounce = Timer(const Duration(milliseconds: 400), () {
      // Reset search when empty
      if (value.trim().isEmpty) {
        vm.clearSearch(); // create this in your VM to clear list & flags
        return;
      }

      vm.currentKeyword = value; // make sure you have this field in VM
      vm.searchAllProduct(
        keyword: value,
        offset: 0,
        limit: _pageSize,
        userID:  LocalStorage.userModel==null?0: LocalStorage.userModel!.id
      );
    });
  }

  void _onScroll() {
    final vm = Provider.of<ProductModelViewModel>(context, listen: false);

    if (!_scrollController.hasClients) return;
    final thresholdPixels = 200; // how close to bottom before loading more

    final maxScroll = _scrollController.position.maxScrollExtent;
    final currentScroll = _scrollController.position.pixels;

    if (maxScroll - currentScroll <= thresholdPixels) {
      if (!vm.isLoadingMore && vm.hasMore && vm.currentKeyword.isNotEmpty) {
        vm.searchAllProduct(
          keyword: vm.currentKeyword,
          offset: vm.listSearchAllProduct.length,
          limit: _pageSize, userID: LocalStorage.userModel==null?0: LocalStorage.userModel!.id,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = Provider.of<ProductModelViewModel>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header: back + search
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade200,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(CupertinoIcons.back, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),

                  // Search bar
                  Expanded(
                    child: Container(
                      height: 45,
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 5,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.search, color: Colors.grey.shade700),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _searchController,
                              onChanged: _onSearchChanged,
                              decoration: InputDecoration(
                                hintText: widget.title,
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                          if (_searchController.text.isNotEmpty)
                            GestureDetector(
                              onTap: () {
                                _searchController.clear();
                                vm.clearSearch();
                                setState(() {}); // update suffix icon
                              },
                              child: Icon(Icons.close,
                                  size: 18, color: Colors.grey.shade600),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Body
            Expanded(
              child: _buildBody(vm),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(ProductModelViewModel vm) {
    // First load skeleton
    if (vm.isFirstLoad && vm.isLoading) {
      return ListView.builder(
        itemCount: 6,
        padding: const EdgeInsets.only(top: 4),
        itemBuilder: (_, __) => _skeletonItem(),
      );
    }

    // No results + no keyword
    if (vm.listSearchAllProduct.isEmpty && vm.currentKeyword.isEmpty) {
      return Center(
        child: Text(
          "Start typing to search...",
          style: TextStyle(
            color: Colors.grey.shade500,
            fontSize: 16,
          ),
        ),
      );
    }

    // No results for this keyword
    if (vm.listSearchAllProduct.isEmpty && vm.currentKeyword.isNotEmpty) {
      return Center(
        child: Text(
          "No results found.",
          style: TextStyle(
            color: Colors.grey.shade500,
            fontSize: 16,
          ),
        ),
      );
    }

    // Show list with optional loading-more at bottom
    return ListView.builder(
      controller: _scrollController,
      itemCount: vm.listSearchAllProduct.length + (vm.isLoadingMore ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == vm.listSearchAllProduct.length) {
          // last item = loading more
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
          );
        }

        final ProductModel product = vm.listSearchAllProduct[index];
        return ProductItemCard(
          product: product,
          onTap: () {
            Navigation.goPage(context: context, page: ItemDetailPage(productModel: product));
          },
        );
      },
    );
  }

  // Simple skeleton placeholder (fake loading card)
  Widget _skeletonItem() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 14,
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                Container(
                  height: 12,
                  margin: const EdgeInsets.only(bottom: 8),
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                Container(
                  height: 14,
                  width: 80,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
