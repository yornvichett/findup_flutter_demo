import 'package:findup_mvvm/Core/Storage/show_mode_storage.dart';
import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/constants/text_helper.dart';
import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:findup_mvvm/Core/services/check_screen.dart';
import 'package:findup_mvvm/Core/services/helper.dart';
import 'package:findup_mvvm/Core/services/local_storage.dart';
import 'package:findup_mvvm/Core/services/translate.dart';
import 'package:findup_mvvm/Core/utils/large_card_item_element.dart';
import 'package:findup_mvvm/Core/utils/list_card_item.dart';
import 'package:findup_mvvm/Core/utils/no_item_text_widget.dart';
import 'package:findup_mvvm/Core/utils/slide_auto_scroll_element.dart';
import 'package:findup_mvvm/Core/utils/sub_category_horizon_scroll.dart';
import 'package:findup_mvvm/Data/models/product_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:findup_mvvm/Data/view_models/slide_view_model.dart';
import 'package:findup_mvvm/Data/view_models/sub_category_view_modle.dart';
import 'package:findup_mvvm/Pages/_Profile/User_Auth/login_page.dart';
import 'package:findup_mvvm/Pages/_User_Filter/item_detail_page.dart';
import 'package:findup_mvvm/Pages/_User_Filter/to_view_user_post_profile_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TopShowViewPage extends StatefulWidget {
  SubCategoryViewModle subCategoryViewModle;
  // List<ProductModel> listTopShow;
  TopShowViewPage({
    super.key,
    required this.subCategoryViewModle,
    // required this.listTopShow,
  });

  @override
  State<TopShowViewPage> createState() => _TopShowViewPageState();
}

class _TopShowViewPageState extends State<TopShowViewPage> {
  TextHelper textHelper = TextHelper();
  CheckScreen checkScreen = CheckScreen();
  Helper helper = Helper();
  ValueNotifier<bool> isListMode = ValueNotifier(false);
  String mode = '';

  @override
  void initState() {
    super.initState();
    widget.subCategoryViewModle.listSubCategoryView.first.is_selected = true;
    int firsSubCatID = widget.subCategoryViewModle.listSubCategoryView.first.id;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      mode = await ShowModeStorage.getModeCache();
      context.read<ProductModelViewModel>().getTopProductBySubCategory(
        userID: LocalStorage.userModel == null ? 0 : LocalStorage.userModel!.id,
        subCategoryID: firsSubCatID,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    SlideViewModel slideViewModel=Provider.of<SlideViewModel>(context,listen: false);
    Size size = MediaQuery.of(context).size;
    ProductModelViewModel productModelViewModel =
        Provider.of<ProductModelViewModel>(context);
    if (mode == 'list' || mode == '') {
      isListMode.value = true;
    } else {
      isListMode.value = false;
    }
    return Scaffold(
      backgroundColor: AppColor.backgroundColor,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: AppColor.appBarColor,
        title: Text(
          Translator.translate('top_show'),
          style: textHelper.textAppBarStyle(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              buildSlideAdvertise(
                loadingPathTemp: 'assets/slide/top_slide1.png',
                radius: 0,
                imgList: [
                  slideViewModel.listSlideTop.first.imageUrl
                
                ],
                height: checkScreen.isTablet(context)
                    ? (33 / 100) * size.height
                    : (25 / 100) * size.height,
              ),
              SizedBox(height: 10),

              SubCategoryHorizonScroll(
                listSUbCategory:
                    widget.subCategoryViewModle.listSubCategoryView,
                onTab: (item) async {
                  widget.subCategoryViewModle.tabSubCategory(item);
                  await productModelViewModel.getTopProductBySubCategory(
                    userID: LocalStorage.userModel == null
                        ? 0
                        : LocalStorage.userModel!.id,
                    subCategoryID: item.id,
                  );
                },
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Translator.translate('recommended'),
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  GestureDetector(
                    onTap: () {
                      isListMode.value = !isListMode.value;
                      if (mode == '' || mode == 'list') {
                        ShowModeStorage.saveModeCache(mode: "grid");
                      } else {
                        ShowModeStorage.saveModeCache(mode: "list");
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ValueListenableBuilder(
                        valueListenable: isListMode,
                        builder: (context, value, child) {
                          return Icon(
                            isListMode.value == false
                                ? Icons.view_list_sharp
                                : Icons.grid_view_outlined,
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              productModelViewModel.listTopShowBySubCategoryFilter.isEmpty
                  ? NoItemTextWidget()
                  : ValueListenableBuilder(
                    valueListenable: isListMode,
                    builder: (context, value, child) {
                      return ListView.builder(
                          physics:
                              NeverScrollableScrollPhysics(), // disable inner scrolling
                          shrinkWrap: true, // important!
                          itemCount: productModelViewModel
                              .listTopShowBySubCategoryFilter
                              .length,
                          itemBuilder: (context, index) {
                            ProductModel productModel = productModelViewModel
                                .listTopShowBySubCategoryFilter[index];
                            List<String> listImage = helper.productModelSplitImage(
                              product: productModel,
                              path: 'property',
                              context: context
                            );
                            return isListMode.value
                                ? ListCardItem(
                                    productModel: productModel,
                                    onTap: () {
                                      Navigation.goPage(
                                        context: context,
                                        page: ItemDetailPage(
                                          productModel: productModel,
                                        ),
                                      );
                                    },
                                  )
                                : Column(
                                    children: [
                                      LargeCardItemElement(
                                        productModel: productModel,
                                        showOptionControllItem: false,
                                        images: listImage,
                                        onTab: () {
                                          Navigation.goPage(
                                            context: context,
                                            page: ItemDetailPage(
                                              productModel: productModel,
                                            ),
                                          );
                                        },
                                        onGoProfile: () {
                                          if (LocalStorage.userModel == null) {
                                            Navigation.goPage(
                                              context: context,
                                              page: LoginPage(),
                                            );
                                          } else {
                                            Navigation.goPage(
                                              context: context,
                                              page: ToViewUserPostProfilePage(
                                                paramProductModel: productModel,
                                              ),
                                            );
                                          }
                                        },
                                      ),
                                      helper.borderCustom(size: size),
                                    ],
                                  );
                          },
                        );
                    }
                  ),
            ],
          ),
        ),
      ),
      // Color(0xff344a58)
    );
  }

  Widget buildSlideAdvertise({
    required double height,
    required List<String> imgList,
    required double radius,
    required String loadingPathTemp,
  }) {
    return SlideAutoScrollElement(
      loadingPathTemp: loadingPathTemp,
      imagePaths: imgList,
      isAsset: false,
      interval: Duration(seconds: 10), // stay 4 seconds per slide
      slideDuration: Duration(milliseconds: 800), // slide animation speed
      hight: height,
      radius: radius,
    );
  }
}
