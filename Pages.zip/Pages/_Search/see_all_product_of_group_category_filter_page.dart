import 'package:findup_mvvm/Core/Storage/show_mode_storage.dart';
import 'package:findup_mvvm/Core/constants/app_color.dart';
import 'package:findup_mvvm/Core/constants/text_helper.dart';
import 'package:findup_mvvm/Core/navigation/navigation.dart';
import 'package:findup_mvvm/Core/services/check_screen.dart';
import 'package:findup_mvvm/Core/services/helper.dart';
import 'package:findup_mvvm/Core/services/local_storage.dart';
import 'package:findup_mvvm/Core/services/translate.dart';
import 'package:findup_mvvm/Core/utils/group_categ_horizon_scroll.dart';
import 'package:findup_mvvm/Core/utils/large_card_item_element.dart';
import 'package:findup_mvvm/Core/utils/list_card_item.dart';
import 'package:findup_mvvm/Core/utils/no_item_text_widget.dart';
import 'package:findup_mvvm/Core/utils/slide_auto_scroll_element.dart';
import 'package:findup_mvvm/Core/utils/sub_category_horizon_scroll.dart';
import 'package:findup_mvvm/Data/models/group_place_model.dart';
import 'package:findup_mvvm/Data/models/product_model.dart';
import 'package:findup_mvvm/Data/models/sub_category_model.dart';
import 'package:findup_mvvm/Data/view_models/group_category_view_model.dart';
import 'package:findup_mvvm/Data/view_models/group_place_view_model.dart';
import 'package:findup_mvvm/Data/view_models/product_model_view_model.dart';
import 'package:findup_mvvm/Data/view_models/slide_view_model.dart';
import 'package:findup_mvvm/Data/view_models/sub_category_view_modle.dart';
import 'package:findup_mvvm/Pages/_Map/map_show_screen.dart';
import 'package:findup_mvvm/Pages/_Profile/User_Auth/login_page.dart';
import 'package:findup_mvvm/Pages/_Search/dialog_search_all.dart';
import 'package:findup_mvvm/Pages/_Search/see_all_product_of_group_category_search.dart';
import 'package:findup_mvvm/Pages/_User_Filter/item_detail_page.dart';
import 'package:findup_mvvm/Pages/_User_Filter/to_view_user_post_profile_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SeeAllProductOfGroupCategoryFilterPage extends StatefulWidget {
  SubCategoryViewModle subCategoryViewModle;
  int groupCategoryID;
  String title;

  SeeAllProductOfGroupCategoryFilterPage({
    super.key,
    required this.subCategoryViewModle,
    required this.groupCategoryID,
    required this.title
  });

  @override
  State<SeeAllProductOfGroupCategoryFilterPage> createState() =>
      _SeeAllProductOfGroupCategoryFilterPageState();
}

class _SeeAllProductOfGroupCategoryFilterPageState
    extends State<SeeAllProductOfGroupCategoryFilterPage> {
  TextHelper textHelper = TextHelper();
  CheckScreen checkScreen = CheckScreen();
  Helper helper = Helper();
  ProductModelViewModel? productModelViewModel;
  ValueNotifier<String> keyTitle = ValueNotifier('');
  ValueNotifier<bool> isListMode = ValueNotifier(false);
  String mode = '';
  @override
  void initState() {
    super.initState();
    widget.subCategoryViewModle.listSubCategoryView.first.is_selected = true;
    keyTitle.value =
        widget.subCategoryViewModle.listSubCategoryView.first.keyTranslate;
    int firsSubCatID = widget.subCategoryViewModle.listSubCategoryView.first.id;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      mode = await ShowModeStorage.getModeCache();

      context.read<ProductModelViewModel>().getProductBySubCategory(
        userID: LocalStorage.userModel == null ? 0 : LocalStorage.userModel!.id,
        subCategoryID: firsSubCatID,
      );
      if (mode == 'list' || mode == '') {
        isListMode.value = true;
      } else {
        isListMode.value = false;
      }
    });
  }

  void FilterData({
    required int userID,
    required SubCategoryModel subCagoryModel,
  }) async {
    await productModelViewModel!.getProductBySubCategory(
      userID: userID,
      subCategoryID: subCagoryModel.id,
    );
  }

  @override
  Widget build(BuildContext context) {
    SlideViewModel slideViewModel = Provider.of<SlideViewModel>(
      context,
      listen: false,
    );
    Size size = MediaQuery.of(context).size;
    productModelViewModel = Provider.of<ProductModelViewModel>(context);

    return Scaffold(
      backgroundColor: AppColor.backgroundColor,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: AppColor.appBarColor,
        title: Text(
          Translator.translate(widget.title),
          style: textHelper.textAppBarStyle(),
        ),
        actions: [
          GestureDetector(
            onTap: () {
              helper.showScreenPopUp(
                context: context,
                title: "All Product",
                child: PopUPSeeAllProductOfGroupCategorySearch(title: "all_product",groupCategoryID: widget.groupCategoryID,),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.search, size: 28),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Advertisement
              buildSlideAdvertise(
                loadingPathTemp: 'assets/slide/top_slide1.png',
                radius: 0,
                imgList: [slideViewModel.listSlideTop.first.imageUrl],
                height: checkScreen.isTablet(context)
                    ? (33 / 100) * size.height
                    : (25 / 100) * size.height,
              ),
              SizedBox(height: 10),
              // Sub Category
              SubCategoryHorizonScroll(
                listSUbCategory:
                    widget.subCategoryViewModle.listSubCategoryView,
                onTab: (item) {
                  keyTitle.value = item.keyTranslate;
                  widget.subCategoryViewModle.tabSubCategory(item);
                  FilterData(
                    userID: LocalStorage.userModel == null
                        ? 0
                        : LocalStorage.userModel!.id,
                    subCagoryModel: item,
                  );
                },
              ),
              SizedBox(height: 10),
              productModelViewModel!.listGetProductBySubCategory.isEmpty
                  ? NoItemTextWidget()
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ValueListenableBuilder(
                          valueListenable: keyTitle,
                          builder: (context, value, child) {
                            return Text(
                              Translator.translate(keyTitle.value),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            );
                          },
                        ),
                        GestureDetector(
                          onTap: () async {
                            isListMode.value = !isListMode.value;

                            if (mode == '' || mode == 'list') {
                              ShowModeStorage.saveModeCache(mode: "grid");
                            } else {
                              ShowModeStorage.saveModeCache(mode: "list");
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ValueListenableBuilder(
                              valueListenable: isListMode,
                              builder: (context, value, child) {
                                return Icon(
                                  isListMode.value == false
                                      ? Icons.view_list_sharp
                                      : Icons.grid_view_outlined,
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
              SizedBox(height: 10),
              ListView.builder(
                physics:
                    NeverScrollableScrollPhysics(), // disable inner scrolling
                shrinkWrap: true, // important!
                itemCount:
                    productModelViewModel!.listGetProductBySubCategory.length,
                itemBuilder: (context, index) {
                  ProductModel productModel =
                      productModelViewModel!.listGetProductBySubCategory[index];
                  List<String> listImage = helper.productModelSplitImage(
                    product: productModel,
                    path: 'property',
                    context: context,
                  );
                  return ValueListenableBuilder(
                    valueListenable: isListMode,
                    builder: (context, value, child) {
                      return Column(
                        children: [
                          isListMode.value
                              ? ListCardItem(
                                  productModel: productModel,
                                  onTap: () {
                                    Navigation.goPage(
                                      context: context,
                                      page: ItemDetailPage(
                                        productModel: productModel,
                                      ),
                                    );
                                  },
                                )
                              : LargeCardItemElement(
                                  productModel: productModel,
                                  showOptionControllItem: false,
                                  images: listImage,
                                  onTab: () {
                                    Navigation.goPage(
                                      context: context,
                                      page: ItemDetailPage(
                                        productModel: productModel,
                                      ),
                                    );
                                  },
                                  onGoProfile: () {
                                    if (LocalStorage.userModel == null) {
                                      Navigation.goPage(
                                        context: context,
                                        page: LoginPage(),
                                      );
                                    } else {
                                      Navigation.goPage(
                                        context: context,
                                        page: ToViewUserPostProfilePage(
                                          paramProductModel: productModel,
                                        ),
                                      );
                                    }
                                  },
                                ),
                          helper.borderCustom(size: size),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
      // Color(0xff344a58)
    );
  }

  Widget buildSlideAdvertise({
    required double height,
    required List<String> imgList,
    required double radius,
    required String loadingPathTemp,
  }) {
    return SlideAutoScrollElement(
      loadingPathTemp: loadingPathTemp,
      imagePaths: imgList,
      isAsset: false,
      interval: Duration(seconds: 10), // stay 4 seconds per slide
      slideDuration: Duration(milliseconds: 800), // slide animation speed
      hight: height,
      radius: radius,
    );
  }

  // void showScreenPopUp({required BuildContext context,required String title}) {
  //   showGeneralDialog(
  //     context: context,
  //     barrierDismissible: true,
  //     barrierLabel: "Map Dialog",
  //     barrierColor: Colors.black54, // background dim
  //     transitionDuration: const Duration(milliseconds: 500),
  //     pageBuilder: (context, animation, secondaryAnimation) {
  //       return Center(
  //         child: SearchScreen(title: title,)
  //       );
  //     },
  //     transitionBuilder: (context, animation, secondaryAnimation, child) {
  //       final curvedValue = Curves.easeInOut.transform(animation.value) - 1.0;
  //       return Transform.translate(
  //         offset: Offset(0.0, curvedValue * -50), // slide from bottom
  //         child: Opacity(opacity: animation.value, child: child),
  //       );
  //     },
  //   );
  // }
}
